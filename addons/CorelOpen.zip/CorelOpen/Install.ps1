﻿$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
$src = Split-Path -Parent $MyInvocation.MyCommand.Path
$dst = Join-Path $env:LOCALAPPDATA 'CorelOpen'
foreach ($f in 'CorelOpen.vbs', 'CorelOpen.ps1') {
    if (-not (Test-Path -LiteralPath (Join-Path $src $f))) {
        [void][System.Windows.Forms.MessageBox]::Show("Не найден файл $f рядом с установщиком. Распакуйте архив целиком и запустите Install.cmd из папки.", 'CorelOpen', 'OK', 'Error')
        exit 1
    }
}
# Рабочие файлы копируются в постоянную папку профиля — папку с установщиком потом можно удалить
New-Item -ItemType Directory -Path $dst -Force | Out-Null
foreach ($f in 'CorelOpen.vbs', 'CorelOpen.ps1') { Copy-Item -LiteralPath (Join-Path $src $f) -Destination $dst -Force }
$cfgSrc = Join-Path $src 'AllowedFolders.txt'
$cfgDst = Join-Path $dst 'AllowedFolders.txt'
if ((Test-Path -LiteralPath $cfgSrc) -and -not (Test-Path -LiteralPath $cfgDst)) { Copy-Item -LiteralPath $cfgSrc -Destination $cfgDst }
$vbs = Join-Path $dst 'CorelOpen.vbs'
$k = 'HKCU:\Software\Classes\corelopen'
New-Item -Path $k -Force | Out-Null
Set-ItemProperty -Path $k -Name '(default)' -Value 'URL:CorelOpen'
New-ItemProperty -Path $k -Name 'URL Protocol' -Value '' -PropertyType String -Force | Out-Null
New-Item -Path "$k\shell\open\command" -Force | Out-Null
Set-ItemProperty -Path "$k\shell\open\command" -Name '(default)' -Value ('wscript.exe "{0}" "%1"' -f $vbs)
[void][System.Windows.Forms.MessageBox]::Show("Готово. Кнопка 📂 в приложении теперь открывает файлы CorelDRAW.`n`nПапку с установщиком можно удалить.`n`nПри первом нажатии 📂 браузер спросит разрешение — выберите «Всегда разрешать».", 'CorelOpen', 'OK', 'Information')
