﻿param([string]$Url)
# Открывает .cdr файл по ссылке corelopen://open/<путь в base64url>. Ничего, кроме .cdr, не запускает.
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Windows.Forms
function Show-Err([string]$m) {
    [void][System.Windows.Forms.MessageBox]::Show($m, 'Листовой материал', 'OK', 'Warning')
    exit 1
}

if ($Url -notmatch '^corelopen://open/([A-Za-z0-9_-]+)/?$') { Show-Err 'Неверная ссылка на файл.' }
$b = $Matches[1].Replace('-', '+').Replace('_', '/')
$b = $b + ('=' * ((4 - $b.Length % 4) % 4))
try {
    $path = [Text.Encoding]::UTF8.GetString([Convert]::FromBase64String($b))
    $full = [IO.Path]::GetFullPath($path)
} catch {
    Show-Err 'Не удалось прочитать путь к файлу из ссылки.'
}

if ([IO.Path]::GetExtension($full) -ne '.cdr') { Show-Err "Открываются только файлы .cdr:`n$full" }

# Разрешённые папки (необязательно): файл AllowedFolders.txt рядом со скриптом, по одной папке в строке.
$cfg = Join-Path $PSScriptRoot 'AllowedFolders.txt'
$roots = @()
if (Test-Path -LiteralPath $cfg) {
    $roots = @(Get-Content -LiteralPath $cfg -Encoding UTF8 | ForEach-Object { $_.Trim() } | Where-Object { $_ -and -not $_.StartsWith('#') })
}
if ($roots.Count -gt 0) {
    $ok = $false
    foreach ($r in $roots) {
        $rr = [IO.Path]::GetFullPath($r).TrimEnd('\') + '\'
        if ($full.StartsWith($rr, [StringComparison]::OrdinalIgnoreCase)) { $ok = $true; break }
    }
    if (-not $ok) { Show-Err "Файл вне разрешённых папок (AllowedFolders.txt):`n$full" }
} elseif ($full -notmatch '^[A-Za-z]:\\') {
    Show-Err "Сетевые пути по умолчанию запрещены. Добавьте папку в AllowedFolders.txt:`n$full"
}

if (-not (Test-Path -LiteralPath $full -PathType Leaf)) {
    Show-Err "Файл не найден:`n$full`n`nВозможно, его переместили или переименовали. Откройте его в CorelDRAW и запустите макрос «ОткрытьЗаказ» — путь обновится."
}
Start-Process -FilePath $full
