﻿Add-Type -AssemblyName System.Windows.Forms
Remove-Item -Path 'HKCU:\Software\Classes\corelopen' -Recurse -Force -ErrorAction SilentlyContinue
Remove-Item -Path (Join-Path $env:LOCALAPPDATA 'CorelOpen') -Recurse -Force -ErrorAction SilentlyContinue
[void][System.Windows.Forms.MessageBox]::Show('Готово: кнопка 📂 больше не открывает файлы, программа удалена.', 'CorelOpen', 'OK', 'Information')
