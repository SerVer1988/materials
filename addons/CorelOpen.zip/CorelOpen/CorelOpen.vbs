Option Explicit
' Obrabotchik ssylok corelopen://open/<base64 puti>. Zapuskaet CorelOpen.ps1 bez okna.
Dim sh, fso, dir, url, cmd
Set sh = CreateObject("WScript.Shell")
Set fso = CreateObject("Scripting.FileSystemObject")
dir = fso.GetParentFolderName(WScript.ScriptFullName)
If WScript.Arguments.Count = 0 Then WScript.Quit
url = Replace(WScript.Arguments(0), """", "")
cmd = "powershell.exe -NoProfile -NonInteractive -WindowStyle Hidden -ExecutionPolicy Bypass -File """ & dir & "\CorelOpen.ps1"" -Url """ & url & """"
sh.Run cmd, 0, False
